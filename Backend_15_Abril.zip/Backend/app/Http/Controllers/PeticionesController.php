<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\File;
use App\Models\Peticione;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use function Symfony\Component\Translation\t;

class PeticionesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['index', 'show', 'list']]);
    }

    public function index(Request $request)
    {
        $peticiones = Peticione::all()-> load(['user', 'categoria', 'files' ]);
        return $peticiones;
    }


    public function update(Request $request, $id)
    {
        $peticion = Peticione::findOrFail($id);
        $peticion->update($request->all());
        return $peticion;
    }

    public function listMine(Request $request)
    {
        // parent::index()
        $user = Auth::user();
        //$id = 1;
        $peticiones = Peticione::all()->where('user_id', $user->id);
        return $peticiones;
    }

    public function show(Request $request, $id)
    {
        $peticion = Peticione::findOrFail($id)-> load(['user', 'categoria', 'files']);
        return $peticion;
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request-> all(),
            [
                'titulo' => 'required|max:255',
                'descripcion' => 'required',
                'destinatario' => 'required',
                'categoria_id' => 'required',
                // 'file' => 'required',
            ]);
        if ($validator->fails()){
            return response()->json(['error'=> $validator -> errors(), 401]);
        }
        $validator = Validator::make($request->all(),
            [
                'file' => 'required|max:4096'
            ]);
        if($validator->fails()){
            return response()->json(['error' => $validator->error()], 402);
        }

        $input = $request->all();
        if($file = $request->file('file')){
            $name = $file->getClientOriginalName();
            Storage::put($name, file_get_contents($request->file('file')->getRealPath()));
            $file->move('storage/', $name);
            $input['file'] = $name;
        }

        //$input = $request->all();
        $category = Categoria::findOrFail($request->input('categoria_id'));
        //$user=1; //harcodeamos el usuario
        $user = Auth::user(); //asociarlo al usuario authenticado
        $user = User::findOrFail($user->id);

        $peticion = new Peticione($input);
        $peticion -> titulo = $request->input('titulo');
        $peticion -> descripcion = $request->input('descripcion');
        $peticion -> destinatario = $request->input('destinatario');

        $peticion->user()->associate($user);
        $peticion->categoria()->associate($category);

        $peticion->firmantes = 0;
        $peticion->estado = 'pendiente';
        $res = $peticion->save();

        $imgdb = new File();
        $imgdb-> name = $input['file'];
        $imgdb-> file_path = 'storage/'.$input['file'];
        $imgdb-> peticione_id = $peticion->id;
        $imgdb-> save();

        if($res){
            return response() ->json(['message' => 'Peticion creada satisfactoriamente', 'peticion' => $peticion],201);
        }
        return  response() -> json (['message' => 'Error creando la peticion'], 500);
    }

    public function cambiarEstado(Request $request, $id)
    {
        $peticion = Peticione::findOrFail($id);
        if ($request->user()->cannot('cambiarEstado', $peticion)) {
            return response()->json(['message' => 'No estás autorizado para realizar esta acción'], 403);
        }
        $peticion->estado = 'aceptada';
        $res = $peticion->save();
        if ($res){
            return response()->json(['message'=> 'Peticion actualizada satisfactoriamente', 'peticion'=>$peticion],201);
        }
        return response()->json(['message'=> 'Error al actulizar la peticion', 'peticion'],500);
    }
    public function delete(Request $request, $id)
    {
        $peticion = Peticione::findOrFail($id);
        $peticion->delete();
        return $peticion;
    }

    public function firmar(Request $request, $id)
    {
        try {
            $peticion = Peticione::findOrFail($id);
            $user = Auth::user();
            //$user = 1;
            //$user_id = [$user];
            $firmas = $peticion->firmas;
            foreach ($firmas as $firma){
                if($firma->id == $user->id){
                    return response()->json(['message'=> 'Ya has firmado correctamnete'],403);
                }
            }
            $user_id = [$user->id];
            $peticion->firmas()->attach($user_id);
            $peticion->firmantes = $peticion->firmantes + 1;
            $peticion->save();
        }catch (\Throwable$th){
            return response()->json(['message'=> 'La peticion no se ha firmado correctamnete'],500);
        }
        return response()->json(['message' => 'Peticion firmada satisfactioriamente', 'peticion' => $peticion], 201);
    }

}
