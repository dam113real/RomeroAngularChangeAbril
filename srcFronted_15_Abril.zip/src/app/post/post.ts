export interface Post {
  files: any;
categoria_id: any;
estado: any;
    id: number;
    titulo: string;
    descripcion: string;
    destinatario: string;
    firmantes: number;
    }   