import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
   
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
  
import { Post } from './post';
   
@Injectable({
  providedIn: 'root'
})
export class PostService {
  getAllCategories() {
    throw new Error('Method not implemented.');
  }
   
  private apiURL = "http://127.0.0.1:8000/api/peticiones/";
   
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  
  constructor(private httpClient: HttpClient) { }
   
  getAll(): Observable<Post[]> {
    return this.httpClient.get<Post[]>(this.apiURL)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
//ESTE ES MI CREATE CON EL QUE ME IBA 

// create(peticion:FormData): Observable<any>{
//   const headers = new HttpHeaders();
//   headers.append('Content-Type', 'multipart/form-data');
//   headers.append('Accept', 'applications/json');
//   // return this.httpClient.post(this.apiURL + '/peticiones/', peticion, {headers:headers})
//   return this.httpClient.post(this.apiURL +  peticion, {headers:headers})
//   .pipe(
//     catchError(this.errorHandler)
//   )
// }

//CREATE CAMBIANDO EL PETICION POR POST Y EN EL RETURN CAMBIAMOS /peticiones/ por "post"


create(post:FormData): Observable<any>{
  const headers = new HttpHeaders();
  headers.append('Content-Type', 'multipart/form-data');
  headers.append('Accept', 'applications/json');
  return this.httpClient.post(this.apiURL, post, {headers:headers})
  .pipe(
    catchError(this.errorHandler)
  )
}

  // create(post: Post): Observable<Post> {
  //   return this.httpClient.post<Post>(this.apiURL , JSON.stringify(post), this.httpOptions)
  //   .pipe(
  //     catchError(this.errorHandler)
  //   )
  // }  
  // firmar(id:number): Observable<any> {
  //   return this.httpClient.get(this.apiURL + '/peticiones/firmar/' + id);
  // }

  find(id: Number): Observable<Post> {
    return this.httpClient.get<Post>(this.apiURL + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  update(id: Number, post: Post): Observable<Post> {
    return this.httpClient.put<Post>(this.apiURL + id, JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  delete(id: Number){
    return this.httpClient.delete<Post>(this.apiURL  + id, this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
  
  errorHandler(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}