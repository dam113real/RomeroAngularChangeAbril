import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

// User interface
export interface User {
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
 
  signin(user: User): Observable<any> {
    return this.http.post<any>('http://127.0.0.1:8000/api/login', user);
  }
  
  constructor(private http: HttpClient) {}

  // User registration
  register(user: User): Observable<any> {
    return this.http.post('http://127.0.0.1:8000/api/register', user).pipe(
      catchError(error => {
        return throwError(error);
      })
    );
  }

  // Login
  login(user: User): Observable<any> {
    return this.http.post<any>('http://127.0.0.1:8000/api/login', user).pipe(
      catchError(error => {
        return throwError(error);
      })
    );
  }
  profileUser(): Observable<any> {
    return this.http.get<any>('http://127.0.0.1:8000/api/me');
  }

  // Logout
  logout(): void {
    // Aquí puedes agregar lógica para limpiar la sesión del usuario, como eliminar el token de autenticación del almacenamiento local
    // Por ejemplo:
    localStorage.removeItem('token');
  }

  // Verificar si el usuario está logueado
  isLoggedIn(): boolean {
    // Aquí puedes agregar lógica para verificar si el usuario está logueado, por ejemplo, si hay un token de autenticación en el almacenamiento local
    // Por ejemplo:
    return !!localStorage.getItem('token');
  }
}
