import { Component } from '@angular/core';
import { AuthService } from '../shared/auth.service';
// Asegúrate de importar el servicio de autenticación adecuado
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
isSignedIn: any;
signOut() {
throw new Error('Method not implemented.');
}
  constructor(private authService: AuthService, private router: Router) {}

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn(); // Utilizamos el servicio de autenticación para verificar si el usuario está logueado
  }

  logout() {
    this.authService.logout(); // Utilizamos el servicio de autenticación para cerrar sesión
    this.router.navigate(['/login']); // Redirigimos al usuario a la página de inicio de sesión después del cierre de sesión
  }
}
